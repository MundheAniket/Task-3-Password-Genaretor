# Password Generator

## Description
This is a simple Python program that generates a strong and random password of a specified length. It uses a combination of:
- Uppercase and lowercase letters
- Digits (0-9)
- Special characters (!@#$%^&*)

## How to Run
1. Install Python (if not already installed).
2. Run the program:
```
python password_generator.py
```
3. Enter the desired password length.
4. The program will display the generated password.

## Requirements
- Python 3.x
